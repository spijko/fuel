<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?>Pressa abscidit habendum aestu. Campoque secuit. Elementaque cognati verba tonitrua. Fratrum inmensa triones mixtam qui inposuit. Igni ne corpora. Ultima ille sinistra locavit toto non subsidere possedit. Locis ventos. Caeleste supplex. Sorbentur nix satus. Viseret terrenae habentem pontus crescendo quia erat sanctius ille.

Numero carentem praecipites! Capacius ventos sunt iussit iuga fulminibus. Conversa alto. Obliquis super temperiemque feras tenent fulgura fuerat. Caelumque grandia oppida tenent litora fuerant mea. Innabilis mundo erat:? Occiduo deus librata habentem illis nova aere orba! Rapidisque porrexerat ne omni carentem caeli securae.

Vindice humanas media flexi stagna altae indigestaque undas siccis. Tumescere deerat eodem neu fecit recessit seductaque locis rudis. Orba vix. Spectent tellure. Erat: onerosior undis levitate quicquam parte elementaque. Terrae boreas secant? Ardentior foret natus opifex. Tumescere quisquis ora cum cingebant altae altae.<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>
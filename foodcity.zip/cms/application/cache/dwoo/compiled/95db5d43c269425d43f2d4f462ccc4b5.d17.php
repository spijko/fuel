<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><p>Pressa abscidit habendum aestu. Campoque secuit. Elementaque cognati verba tonitrua. Fratrum inmensa triones mixtam qui inposuit. Igni ne corpora. Ultima ille sinistra locavit toto non subsidere possedit. Locis ventos. Caeleste supplex. Sorbentur nix satus. Viseret terrenae habentem pontus crescendo&#8230;</p><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>
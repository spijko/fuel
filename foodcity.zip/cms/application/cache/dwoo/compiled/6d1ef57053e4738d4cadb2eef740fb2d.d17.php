<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="utf-8">
 	<title>
		<!--__FUEL_MARKER__0-->kill : Home	</title>

	<meta name="keywords" content="<!--__FUEL_MARKER__1-->">
	<meta name="description" content="<!--__FUEL_MARKER__2-->">

	<link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    <link href='/fuel/assets/css/core.css' rel='stylesheet' type='text/css'>
	<link href="/fuel/assets/css/main.css?c=" media="all" rel="stylesheet"/>
	    

</head>
<body>
	<div class="page">
    	<header class="page_header">
				<!--<div class="logo">-->
                <nav role="navigation" id="sidebar-nav" class="sidebar-nav collapse" style="position: fixed; top: 0px;">
	<ul class="sidebar-nav-primary">
		<li class="home active">
			<a href="#"><i class="ico-home"></i><span class="hidden"> Home</span></a>
		</li>
		<li class="save">
			<a href="#"><i class="ico-tag"></i> Save Money</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Save Money</a></li>
													<li>
						<a href="#">Save – 1 </a>
											</li>
									<li>
						<a href="#">Save – 2 </a>
											</li>
									<li>
						<a href="#">Save – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Save – Sub1</a></li>
																	<li><a href="#">Save – Sub2</a></li>
																	<li><a href="#">Save – Sub3</a></li>
																	<li><a href="#">Save – Sub4</a></li>
																	<li><a href="#">Save – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Save – 4 </a>
											</li>
									<li>
						<a href="#">Save – 5 </a>
											</li>
									<li>
						<a href="#">Save – 6 </a>
											</li>
									<li>
						<a href="#">Save – 7 </a>
											</li>
									<li>
						<a href="#">Save – 8 </a>
											</li>
									<li>
						<a href="#">Save – 9 </a>
											</li>
									<li>
						<a href="#">Save – 10 </a>
											</li>
									<li>
						<a href="#">Save – 11 </a>
											</li>
									<li>
						<a href="#">Save – 12 </a>
											</li>
									<li>
						<a href="#">Save – 13 </a>
											</li>
									<li>
						<a href="#">Save – 14 </a>
											</li>
									<li>
						<a href="#">Save – 15 </a>
											</li>
									<li>
						<a href="#">Save – 16 </a>
											</li>
									<li>
						<a href="#">Save – 17 </a>
											</li>
									<li>
						<a href="#">Save – 18 </a>
											</li>
									<li>
						<a href="#">Save – 19 </a>
											</li>
									<li>
						<a href="#">Save – 20 </a>
											</li>
									<li>
						<a href="#">Save – 21 </a>
											</li>
									<li>
						<a href="#">Save – 22 </a>
											</li>
									<li>
						<a href="#">Save – 23 </a>
											</li>
									<li>
						<a href="#">Save – 24 </a>
											</li>
									<li>
						<a href="#">Save – 25 </a>
											</li>
									<li>
						<a href="#">Save – 26 </a>
											</li>
									<li>
						<a href="#">Save – 27 </a>
											</li>
									<li>
						<a href="#">Save – 28 </a>
											</li>
									<li>
						<a href="#">Save – 29 </a>
											</li>
									<li>
						<a href="#">Save – 30 </a>
											</li>
									<li>
						<a href="#">Save – 31 </a>
											</li>
									<li>
						<a href="#">Save – 32 </a>
											</li>
									<li>
						<a href="#">Save – 33 </a>
											</li>
									<li>
						<a href="#">Save – 34 </a>
											</li>
									<li>
						<a href="#">Save – 35 </a>
											</li>
							</ul>
		</li>
		<li class="eat">
			<a href="#"><i class="ico-eatbetter"></i> Eat Better</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Eat Better</a></li>
									<li>
						<a href="#">Eat – 1 </a>
											</li>
									<li>
						<a href="#">Eat – 2 </a>
											</li>
									<li>
						<a href="#">Eat – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Eat – Sub1</a></li>
																	<li><a href="#">Eat – Sub2</a></li>
																	<li><a href="#">Eat – Sub3</a></li>
																	<li><a href="#">Eat – Sub4</a></li>
																	<li><a href="#">Eat – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Eat – 4 </a>
											</li>
									<li>
						<a href="#">Eat – 5 </a>
											</li>
							</ul>
		</li>
		<li class="shop">
			<a href="#"><i class="ico-cart"></i> Shop</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Shop</a></li>
									<li>
						<a href="#">Shop – 1 </a>
											</li>
									<li>
						<a href="#">Shop – 2 </a>
											</li>
									<li>
						<a href="#">Shop – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Shop – Sub1</a></li>
																	<li><a href="#">Shop – Sub2</a></li>
																	<li><a href="#">Shop – Sub3</a></li>
																	<li><a href="#">Shop – Sub4</a></li>
																	<li><a href="#">Shop – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Shop – 4 </a>
											</li>
									<li>
						<a href="#">Shop – 5 </a>
											</li>
							</ul>
		</li>
		<li class="pharmacy">
			<a href="#"><i class="ico-pharmacy"></i> Pharmacy</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Pharmacy</a></li>
									<li>
						<a href="#">Pharmacy – 1 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 2 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Pharmacy – Sub1</a></li>
																	<li><a href="#">Pharmacy – Sub2</a></li>
																	<li><a href="#">Pharmacy – Sub3</a></li>
																	<li><a href="#">Pharmacy – Sub4</a></li>
																	<li><a href="#">Pharmacy – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Pharmacy – 4 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 5 </a>
											</li>
							</ul>
		</li>
		<li class="community">
			<a href="#"><i class="ico-heart"></i> Community</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Community</a></li>
									<li>
						<a href="#">Community – 1 </a>
											</li>
									<li>
						<a href="#">Community – 2 </a>
											</li>
									<li>
						<a href="#">Community – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Community – Sub1</a></li>
																	<li><a href="#">Community – Sub2</a></li>
																	<li><a href="#">Community – Sub3</a></li>
																	<li><a href="#">Community – Sub4</a></li>
																	<li><a href="#">Community – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Community – 4 </a>
											</li>
									<li>
						<a href="#">Community – 5 </a>
											</li>
							</ul>
		</li>
		<li class="dashboard">
			<a href="#"><i class="ico-user2"></i> Dashboard</a>
		</li>
		<li class="quick-info points">
			<a href="#"><span class="count">5</span> Fuel Points</a>
		</li>
		<li class="quick-info visits">
			<a href="#"><span class="count">5</span> Fuel Visits</a>
		</li>
		<li class="coupons clipped">
			<a href="#"><span class="count">5</span> Clipped Coupons</a>
		</li>
		<li class="coupons available">
			<a href="#"><span class="count">227</span> Available Coupons</a>
		</li>
	</ul>
</nav>
                <nav id="navbar" class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="navbar-top container-fluid">
    <div class="navbar-header">
            <span class="welcome">Welcome</span>
      <a class="login" data-toggle="modal" data-target="#login-form-modal" data-remote="false" href="login.php">Login</a><span class="or"> or </span><a class="register" href="#">Register</a>
      <button type="button" class="menu-cog collapsed btn btn-link pull-right" data-toggle="collapse" data-target=".navbar-collapse" data-parent="#navbar">
        <i class="ico-cog"></i><span class="sr-only"> Menu</span>
      </button>
    </div>
    <div class="navbar-collapse collapse no-transition">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown clearfix">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">My Account <i class="ico-arrow"></i></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#"><i class="ico-cog"></i> Account Settings</a></li>
            <li><a href="#"><i class="ico-pencil"></i> Order History</a></li>
            <li><a href="#"><i class="ico-location"></i> My Store</a></li>
            <li><a href="#"><i class="ico-arrow-left2"></i> Logout</a></li>
          </ul>
        </li>
        <li class="">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#navbar-store-finder">
              <span class="cog-menu-icon"><i class="ico-location"></i> </span>Store Finder<span class="hidden-xs hidden-sm"> <i class="ico-arrow"></i></span></a>
        </li>
        <li><a href="#"><span class="cog-menu-icon"><i class="ico-coin"></i> </span>Weekly Ad</a></li>
        <li><a href="#"><span class="cog-menu-icon"><i class="ico-help"></i> </span>Help</a></li>
      </ul>
    </div>
  </div>
  <div id="navbar-store-finder" class="nav navbar-nav navbar-store-finder collapse no-transition clearfix hidden-xs hidden-sm">
    <div class="store-finder-wrapper container-fluid">
      <div class="current-store col-xs-3">
        <h2>Current Store:</h2>
        <div class="vcard">
          <p class="fn sr-only"><a href="#">Store Name</a></p>
          <p class="adr">
            <span class="street-address">5941 Kingston Pike</span><br>
            <span class="locality">Knoxville</span>, <abbr class="region" title="Tennessee">TN</abbr>
            <span class="postal-code">37919</span><br class="hidden">
            <span class="country-name hidden">United States</span>
          </p>
          <p class="tel hidden"><a href="tel:+18659876543">(865) 987-6543</a></p>
        </div>
      </div>
      <form class="col-xs-8 col-xs-offset-1">
        <fieldset class="row">
          <legend class="find-a-store col-xs-5"><i class="ico-location primary"></i> Find a store:</legend>
          <div class="form-group col-xs-5">
            <label for="store-search" class="hidden">ZIP code or City, State</label>
            <input id="store-search" type="search" class="" placeholder="Enter ZIP code or city and state">
          </div>
          <div class="form-group col-xs-2">
            <button type="submit" class="btn btn-lg btn-secondary">Find</button>
          </div>
        </fieldset>
      </form>
    </div>
  </div>
  <div class="nav navbar-nav navbar-bottom clearfix">
    <div class="container-fluid">
      <ul>
        <li class="col-xs-1 hidden-lg">
          <button type="button" class="hamburglar collapsed" data-toggle="collapse" data-target="#sidebar-nav">
            <strong class="sr-only">Toggle Sidebar</strong>
            <span class="burger-bar"></span>
            <span class="burger-bar"></span>
            <span class="burger-bar"></span>
          </button>
        </li>
        <li class="col-xs-4 col-sm-3">
            <a class="logo-container" href="/">
              <img role="logo" alt="Food City Logo" src="/fuel/assets/images/food-city-logo.svg" onerror="this.src='/static/img/food-city-logo.png'">
            </a>
        </li>
        <li class="shopping-list col-xs-3 col-sm-2 col-md-offset-1">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#shopping-list-menu" data-parent="#navbar"><i class="ico-list main-icon"></i><span class="hidden-xs hidden-sm">My </span>List: <span class="shopping-items">4</span><i class="ico-arrow"></i></a>
          <div id="shopping-list-menu" class="collapse no-transition col-xs-12 col-md-9 col-lg-8">
            <div class="list-table-wrapper">
              <table>
                <thead class="table-header">
                  <tr>
                    <th>#</th>
                    <th>Item</th>
                    <th>Aisle</th>
                    <th class="hidden">Del.</th>
                  </tr>
                </thead>
                <tbody>
                                    <tr>
                      <td class="qnty">1</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">1</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">2</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">2</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">3</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">3</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">4</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">4</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">5</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">5</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                  </tbody>
              </table>
              <a href="#" class="btn btn-shop">View List</a>
            </div>
            <form class="quick-add-form">
              <label for="quick-add-to-list" class="table-header">Quick Add</label>
              <textarea id="quick-add-to-list" placeholder="Type a item lookup"></textarea>
              <button type="submit" class="btn btn-dashboard pull-right">Save</button>
            </form>
          </div>
        </li>
        <li class="shopping-cart col-xs-3 col-sm-2">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#shopping-cart-menu" data-parent="#navbar"><i class="ico-cart main-icon"></i><span class="hidden-xs hidden-sm">My </span>Cart: <span class="shopping-items">3</span><i class="ico-arrow"></i></a>
          <div id="shopping-cart-menu" class="collapse no-transition col-xs-12 col-md-9 col-lg-8">
            <table>
              <caption class="table-header">Curbside Pickup Shopping Cart</caption>
              <thead>
                <tr>
                  <th><abbr title="Quantity">Qty.</abbr></th>
                  <th>Item</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                                  <tr>
                    <td class="qnty">1</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">2</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">3</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">4</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">5</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                              </tbody>
            </table>
            <footer>
              <dl class="cart-summary">
                <dt>Cart Summary</dt><!--
                --><dd>Subtotal: <span class="sub-total">$25.32</span></dd>
              </dl>
              <div class="btn-cage">
                  <a class="btn btn-lg btn-shop" href="#">View Cart</a>
                  <a class="btn btn-lg btn-dashboard" href="#">Checkout</a>
              </div>
            </footer>
          </div>
        </li>
        <li class="search-bar col-xs-1 col-sm-4">
          <form id="site-search" class="input-group small-collapse" role="search">
            <div class="input-group-btn">
              <a role="button" class="btn btn-default btn-neutral-gradient search-dropdown dropdown-toggle" data-toggle="dropdown"><span class="ico-arrow"></span><span class="value">All</span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">All</a></li>
                <li><a href="#">Eat</a></li>
                <li><a href="#">Other</a></li>
                <li><a href="#">Testing a longer value name</a></li>
              </ul>
            </div>
            <label for="site-search-input" class="sr-only">Search</label>
            <input id="site-search-input" type="search" class="form-control" placeholder="Search">
            <div class="input-group-btn search-submit">
              <button id="site-search-submbit" type="submit" class="btn btn-primary"><span>Go</span></button>
            </div>
          </form>
        </li>
      </ul>
    </div>
  </div>
</nav>
               <!-- </div>-->
				<h1></h1>
			</header>
		<!--<div class="wrapper"><main id="main" role="main" class="container-fluid static-page community" data-not-on-prod-class-change="">-->
			
             
    <div id="main">
        <div class="wrapper">
             
            <article id="primary">
                <!--__FUEL_MARKER__3--> 
                                <div class="">
<div class="row padded">
			<div class="panel panel-default shadow-both">
	<div class="panel-body alpha-img-header">
				<h1 class="community" data-not-on-prod-class-change="">Category</h1>
		<figure class="alpha-img col-xs-12">
			<div class="cover-container">
				<img alt="community" src="/fuel/assets/images/comparison-chart.jpg" srcset="//placehold.it/2200x540 2x">
			</div>
		</figure>
	</div>
</div>
		</div>
        </div>                                                <div class="row padded">
			<article class="panel panel-default shadow-both">
	<section class="panel-body">
		<div class="col-xs-12">
			<h1 style="margin-top:15px">Our Mission</h1>
			<p>At Food City, we know that a business can only be made stronger by the community it is a part of. We take pride in our local charities, events and residents.</p>
		</div>
	</section>
</article>
		</div>                                                <div class="row padded">
			<div class="row">
	<div class="col-xs-12 col-sm-6">
		<article class="panel panel-default static-callout shadow-both">
			<header class="panel-header alpha-img-header">
				<figure class="alpha-img">
					<div class="cover-container">
						<img alt="community" src="/fuel/assets/images/me.jpg" srcset="//placehold.it/1340x260 2x">
					</div>
				</figure>
			</header>
			<section class="panel-body">
				<h3>Events</h3>
				<p>sadasdasdasdasdsa</p>
								<a href="'google.com'" class="btn btn-lg btn-community" data-not-on-prod-class-change="">View Events</a>
			</section>
		</article>
	</div>
	<div class="col-xs-12 col-sm-6">
		<article class="panel panel-default static-callout shadow-both">
			<header class="panel-header alpha-img-header">
				<figure class="alpha-img">
					<div class="cover-container">
						<img alt="community" src="/fuel/assets/images/survey.jpg" srcset="//placehold.it/1370x260 2x">
					</div>
				</figure>
			</header>
			<section class="panel-body">
				<h3>News</h3>
				<p>asdsadasfqegeqsacasd</p>
								<a href="bing.com" class="btn btn-lg btn-community" data-not-on-prod-class-change="">Read News</a>
			</section>
		</article>
	</div>
</div>
		</div>                                                
 
<div class="row padded">
			<article class="panel panel-default shadow-both">
	<header class="panel-header centered-padded row">
		<div class="col-xs-12">
						<div class="ico-heart ico-header community" data-not-on-prod-class-change=""></div>
			<h1>Our Partners</h1>
			<h4>Community</h4>
		</div>
	</header>
	<section class="panel-body row">
		<div class="col-xs-12 col-lg-10 col-lg-offset-1 columned-img-list-container">
			<ul class="columned-img-list">
             
            
			 <li><img alt="" src="/fuel/assets/images/me.jpg"></li>
  
 			 
            
			 <li><img alt="" src="/fuel/assets/images/Jellyfish.jpg"></li>
  
 			 
            
			 <li><img alt="" src="/fuel/assets/images/Lighthouse.jpg"></li>
  
 												 
									
	</ul>
		</div>
	</section>
</article>
		</div>                                            </article>
        </div>
    </div>
     
<!--</main>
</div>-->
<footer id="footer">
	<section class="footer-top container-fluid">
		<div class="col-xs-2 col-sm-1">
			<a href="#" class="logo-container"><img role="logo" alt="Home Logo" src="/fuel/assets/images/food-city-logo-footer.svg" onerror="this.src='/static/img/food-city-logo-footer.png'"></a>
		</div>
		<div class="col-xs-9 col-sm-10 col-md-11">
			<nav>
				<ul>
					<li><a href="#">About Us</a></li>
					<li><a href="#">Careers</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Online Shopping Help</a></li>
					<li><a href="#"><abbr title="Frequently asked questions">FAQs</abbr></a></li>
				</ul>
				<ul class="social">
					<li><a href="#"><i class="ico-facebook"></i><span class="sr-only"> Facebook</span></a></li>
					<li><a href="#"><i class="ico-twitter"></i><span class="sr-only"> Twitter</span></a></li>
					<li><a href="#"><i class="ico-pinterest"></i><span class="sr-only"> Pinterest</span></a></li>
				</ul>
			</nav>
		</div>
	</section>
	<section class="footer-bottom">
		<nav class="container-fluid">
			<ul>
				<li><a href="#">Associate Resources</a></li>
				<li><a href="#">Consumer Resources</a></li>
				<li><a href="#">Partner Resources</a></li>
								<li><a href="#">Terms &amp; Conditions</a></li>
				<li><a href="#">Privacy Policy</a></li>
				<li><a href="#">Site Map</a></li>
			</ul>
		</nav>
	</section>
</footer><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>
<?php 
// to simplify updates, we post the helpers in the fuel module
require_once(FUEL_PATH.'helpers/MY_url_helper.php');
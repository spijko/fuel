<?php $CI->load->module_view('app', '_install') ?>

<div class="wrapper"></div>
<?php

// or as a page variable in the same file
$pages['home'] = array('layout' => 'home');

?>


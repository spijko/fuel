<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="utf-8">
 	<title>
		<?php 
			if (!empty($is_blog)) :
				echo $CI->fuel_blog->page_title($page_title, ' : ', 'right');
			else:
				echo fuel_var('page_title', '');
			endif;
		?>
	</title>

	<meta name="keywords" content="<?php echo fuel_var('meta_keywords')?>">
	<meta name="description" content="<?php echo fuel_var('meta_description')?>">

	<link href='http://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
    <link href='/fuel/assets/css/core.css' rel='stylesheet' type='text/css'>
	<?php
		echo css('main').css($css);

		if (!empty($is_blog)):
			echo $CI->fuel_blog->header();
		endif;
	?>
    

</head>
<body>
	<div class="page">
    	<header class="page_header">
				<!--<div class="logo">-->
                <nav role="navigation" id="sidebar-nav" class="sidebar-nav collapse" style="position: fixed; top: 0px;">
	<ul class="sidebar-nav-primary">
		<li class="home active">
			<a href="#"><i class="ico-home"></i><span class="hidden"> Home</span></a>
		</li>
		<li class="save">
			<a href="#"><i class="ico-tag"></i> Save Money</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Save Money</a></li>
													<li>
						<a href="#">Save – 1 </a>
											</li>
									<li>
						<a href="#">Save – 2 </a>
											</li>
									<li>
						<a href="#">Save – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Save – Sub1</a></li>
																	<li><a href="#">Save – Sub2</a></li>
																	<li><a href="#">Save – Sub3</a></li>
																	<li><a href="#">Save – Sub4</a></li>
																	<li><a href="#">Save – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Save – 4 </a>
											</li>
									<li>
						<a href="#">Save – 5 </a>
											</li>
									<li>
						<a href="#">Save – 6 </a>
											</li>
									<li>
						<a href="#">Save – 7 </a>
											</li>
									<li>
						<a href="#">Save – 8 </a>
											</li>
									<li>
						<a href="#">Save – 9 </a>
											</li>
									<li>
						<a href="#">Save – 10 </a>
											</li>
									<li>
						<a href="#">Save – 11 </a>
											</li>
									<li>
						<a href="#">Save – 12 </a>
											</li>
									<li>
						<a href="#">Save – 13 </a>
											</li>
									<li>
						<a href="#">Save – 14 </a>
											</li>
									<li>
						<a href="#">Save – 15 </a>
											</li>
									<li>
						<a href="#">Save – 16 </a>
											</li>
									<li>
						<a href="#">Save – 17 </a>
											</li>
									<li>
						<a href="#">Save – 18 </a>
											</li>
									<li>
						<a href="#">Save – 19 </a>
											</li>
									<li>
						<a href="#">Save – 20 </a>
											</li>
									<li>
						<a href="#">Save – 21 </a>
											</li>
									<li>
						<a href="#">Save – 22 </a>
											</li>
									<li>
						<a href="#">Save – 23 </a>
											</li>
									<li>
						<a href="#">Save – 24 </a>
											</li>
									<li>
						<a href="#">Save – 25 </a>
											</li>
									<li>
						<a href="#">Save – 26 </a>
											</li>
									<li>
						<a href="#">Save – 27 </a>
											</li>
									<li>
						<a href="#">Save – 28 </a>
											</li>
									<li>
						<a href="#">Save – 29 </a>
											</li>
									<li>
						<a href="#">Save – 30 </a>
											</li>
									<li>
						<a href="#">Save – 31 </a>
											</li>
									<li>
						<a href="#">Save – 32 </a>
											</li>
									<li>
						<a href="#">Save – 33 </a>
											</li>
									<li>
						<a href="#">Save – 34 </a>
											</li>
									<li>
						<a href="#">Save – 35 </a>
											</li>
							</ul>
		</li>
		<li class="eat">
			<a href="#"><i class="ico-eatbetter"></i> Eat Better</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Eat Better</a></li>
									<li>
						<a href="#">Eat – 1 </a>
											</li>
									<li>
						<a href="#">Eat – 2 </a>
											</li>
									<li>
						<a href="#">Eat – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Eat – Sub1</a></li>
																	<li><a href="#">Eat – Sub2</a></li>
																	<li><a href="#">Eat – Sub3</a></li>
																	<li><a href="#">Eat – Sub4</a></li>
																	<li><a href="#">Eat – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Eat – 4 </a>
											</li>
									<li>
						<a href="#">Eat – 5 </a>
											</li>
							</ul>
		</li>
		<li class="shop">
			<a href="#"><i class="ico-cart"></i> Shop</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Shop</a></li>
									<li>
						<a href="#">Shop – 1 </a>
											</li>
									<li>
						<a href="#">Shop – 2 </a>
											</li>
									<li>
						<a href="#">Shop – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Shop – Sub1</a></li>
																	<li><a href="#">Shop – Sub2</a></li>
																	<li><a href="#">Shop – Sub3</a></li>
																	<li><a href="#">Shop – Sub4</a></li>
																	<li><a href="#">Shop – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Shop – 4 </a>
											</li>
									<li>
						<a href="#">Shop – 5 </a>
											</li>
							</ul>
		</li>
		<li class="pharmacy">
			<a href="#"><i class="ico-pharmacy"></i> Pharmacy</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Pharmacy</a></li>
									<li>
						<a href="#">Pharmacy – 1 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 2 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Pharmacy – Sub1</a></li>
																	<li><a href="#">Pharmacy – Sub2</a></li>
																	<li><a href="#">Pharmacy – Sub3</a></li>
																	<li><a href="#">Pharmacy – Sub4</a></li>
																	<li><a href="#">Pharmacy – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Pharmacy – 4 </a>
											</li>
									<li>
						<a href="#">Pharmacy – 5 </a>
											</li>
							</ul>
		</li>
		<li class="community">
			<a href="#"><i class="ico-heart"></i> Community</a>
			<ul class="sidebar-nav-secondary">
				<li class="subnav-header"><a href="#">Community</a></li>
									<li>
						<a href="#">Community – 1 </a>
											</li>
									<li>
						<a href="#">Community – 2 </a>
											</li>
									<li>
						<a href="#">Community – 3 <i class="ico-arrow"></i></a>
													<ul class="sidebar-nav-tertiary">
																	<li><a href="#">Community – Sub1</a></li>
																	<li><a href="#">Community – Sub2</a></li>
																	<li><a href="#">Community – Sub3</a></li>
																	<li><a href="#">Community – Sub4</a></li>
																	<li><a href="#">Community – Sub5</a></li>
															</ul>
											</li>
									<li>
						<a href="#">Community – 4 </a>
											</li>
									<li>
						<a href="#">Community – 5 </a>
											</li>
							</ul>
		</li>
		<li class="dashboard">
			<a href="#"><i class="ico-user2"></i> Dashboard</a>
		</li>
		<li class="quick-info points">
			<a href="#"><span class="count">5</span> Fuel Points</a>
		</li>
		<li class="quick-info visits">
			<a href="#"><span class="count">5</span> Fuel Visits</a>
		</li>
		<li class="coupons clipped">
			<a href="#"><span class="count">5</span> Clipped Coupons</a>
		</li>
		<li class="coupons available">
			<a href="#"><span class="count">227</span> Available Coupons</a>
		</li>
	</ul>
</nav>
                <nav id="navbar" class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="navbar-top container-fluid">
    <div class="navbar-header">
            <span class="welcome">Welcome</span>
      <a class="login" data-toggle="modal" data-target="#login-form-modal" data-remote="false" href="login.php">Login</a><span class="or"> or </span><a class="register" href="#">Register</a>
      <button type="button" class="menu-cog collapsed btn btn-link pull-right" data-toggle="collapse" data-target=".navbar-collapse" data-parent="#navbar">
        <i class="ico-cog"></i><span class="sr-only"> Menu</span>
      </button>
    </div>
    <div class="navbar-collapse collapse no-transition">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown clearfix">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">My Account <i class="ico-arrow"></i></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#"><i class="ico-cog"></i> Account Settings</a></li>
            <li><a href="#"><i class="ico-pencil"></i> Order History</a></li>
            <li><a href="#"><i class="ico-location"></i> My Store</a></li>
            <li><a href="#"><i class="ico-arrow-left2"></i> Logout</a></li>
          </ul>
        </li>
        <li class="">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#navbar-store-finder">
              <span class="cog-menu-icon"><i class="ico-location"></i> </span>Store Finder<span class="hidden-xs hidden-sm"> <i class="ico-arrow"></i></span></a>
        </li>
        <li><a href="#"><span class="cog-menu-icon"><i class="ico-coin"></i> </span>Weekly Ad</a></li>
        <li><a href="#"><span class="cog-menu-icon"><i class="ico-help"></i> </span>Help</a></li>
      </ul>
    </div>
  </div>
  <div id="navbar-store-finder" class="nav navbar-nav navbar-store-finder collapse no-transition clearfix hidden-xs hidden-sm">
    <div class="store-finder-wrapper container-fluid">
      <div class="current-store col-xs-3">
        <h2>Current Store:</h2>
        <div class="vcard">
          <p class="fn sr-only"><a href="#">Store Name</a></p>
          <p class="adr">
            <span class="street-address">5941 Kingston Pike</span><br>
            <span class="locality">Knoxville</span>, <abbr class="region" title="Tennessee">TN</abbr>
            <span class="postal-code">37919</span><br class="hidden">
            <span class="country-name hidden">United States</span>
          </p>
          <p class="tel hidden"><a href="tel:+18659876543">(865) 987-6543</a></p>
        </div>
      </div>
      <form class="col-xs-8 col-xs-offset-1">
        <fieldset class="row">
          <legend class="find-a-store col-xs-5"><i class="ico-location primary"></i> Find a store:</legend>
          <div class="form-group col-xs-5">
            <label for="store-search" class="hidden">ZIP code or City, State</label>
            <input id="store-search" type="search" class="" placeholder="Enter ZIP code or city and state">
          </div>
          <div class="form-group col-xs-2">
            <button type="submit" class="btn btn-lg btn-secondary">Find</button>
          </div>
        </fieldset>
      </form>
    </div>
  </div>
  <div class="nav navbar-nav navbar-bottom clearfix">
    <div class="container-fluid">
      <ul>
        <li class="col-xs-1 hidden-lg">
          <button type="button" class="hamburglar collapsed" data-toggle="collapse" data-target="#sidebar-nav">
            <strong class="sr-only">Toggle Sidebar</strong>
            <span class="burger-bar"></span>
            <span class="burger-bar"></span>
            <span class="burger-bar"></span>
          </button>
        </li>
        <li class="col-xs-4 col-sm-3">
            <a class="logo-container" href="/">
              <img role="logo" alt="Food City Logo" src="/fuel/assets/images/food-city-logo.svg" onerror="this.src='/static/img/food-city-logo.png'">
            </a>
        </li>
        <li class="shopping-list col-xs-3 col-sm-2 col-md-offset-1">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#shopping-list-menu" data-parent="#navbar"><i class="ico-list main-icon"></i><span class="hidden-xs hidden-sm">My </span>List: <span class="shopping-items">4</span><i class="ico-arrow"></i></a>
          <div id="shopping-list-menu" class="collapse no-transition col-xs-12 col-md-9 col-lg-8">
            <div class="list-table-wrapper">
              <table>
                <thead class="table-header">
                  <tr>
                    <th>#</th>
                    <th>Item</th>
                    <th>Aisle</th>
                    <th class="hidden">Del.</th>
                  </tr>
                </thead>
                <tbody>
                                    <tr>
                      <td class="qnty">1</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">1</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">2</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">2</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">3</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">3</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">4</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">4</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                      <tr>
                      <td class="qnty">5</td>
                      <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                      <td class="aisle align-on-decimal">5</td>
                      <td class="delete"><button class="btn btn-link"><i class="ico-remove"></i></button></td>
                    </tr>
                                  </tbody>
              </table>
              <a href="#" class="btn btn-shop">View List</a>
            </div>
            <form class="quick-add-form">
              <label for="quick-add-to-list" class="table-header">Quick Add</label>
              <textarea id="quick-add-to-list" placeholder="Type a item lookup"></textarea>
              <button type="submit" class="btn btn-dashboard pull-right">Save</button>
            </form>
          </div>
        </li>
        <li class="shopping-cart col-xs-3 col-sm-2">
          <a href="#" class="collapsed" data-toggle="collapse" data-target="#shopping-cart-menu" data-parent="#navbar"><i class="ico-cart main-icon"></i><span class="hidden-xs hidden-sm">My </span>Cart: <span class="shopping-items">3</span><i class="ico-arrow"></i></a>
          <div id="shopping-cart-menu" class="collapse no-transition col-xs-12 col-md-9 col-lg-8">
            <table>
              <caption class="table-header">Curbside Pickup Shopping Cart</caption>
              <thead>
                <tr>
                  <th><abbr title="Quantity">Qty.</abbr></th>
                  <th>Item</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                                  <tr>
                    <td class="qnty">1</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">2</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">3</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">4</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                                  <tr>
                    <td class="qnty">5</td>
                    <td class="item"><a href="#">Food Club Rice Crisps</a></td>
                    <td class="price align-on-decimal">$2.99</td>
                  </tr>
                              </tbody>
            </table>
            <footer>
              <dl class="cart-summary">
                <dt>Cart Summary</dt><!--
                --><dd>Subtotal: <span class="sub-total">$25.32</span></dd>
              </dl>
              <div class="btn-cage">
                  <a class="btn btn-lg btn-shop" href="#">View Cart</a>
                  <a class="btn btn-lg btn-dashboard" href="#">Checkout</a>
              </div>
            </footer>
          </div>
        </li>
        <li class="search-bar col-xs-1 col-sm-4">
          <form id="site-search" class="input-group small-collapse" role="search">
            <div class="input-group-btn">
              <a role="button" class="btn btn-default btn-neutral-gradient search-dropdown dropdown-toggle" data-toggle="dropdown"><span class="ico-arrow"></span><span class="value">All</span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">All</a></li>
                <li><a href="#">Eat</a></li>
                <li><a href="#">Other</a></li>
                <li><a href="#">Testing a longer value name</a></li>
              </ul>
            </div>
            <label for="site-search-input" class="sr-only">Search</label>
            <input id="site-search-input" type="search" class="form-control" placeholder="Search">
            <div class="input-group-btn search-submit">
              <button id="site-search-submbit" type="submit" class="btn btn-primary"><span>Go</span></button>
            </div>
          </form>
        </li>
      </ul>
    </div>
  </div>
</nav>
               <!-- </div>-->
				<h1><?php //echo fuel_var('heading')?></h1>
			</header>
		<!--<div class="wrapper"><main id="main" role="main" class="container-fluid static-page community" data-not-on-prod-class-change="">-->
			
        
<div class="row padded">
			<article class="panel panel-default shadow-both">
	<section class="panel-body">
		<div class="alpha-img alpha-blurb">
			<div class="cover-container">
								<img alt="community" src="<?=img_path($img_header)?>" srcset="//placehold.it/2540x880 2x">
			</div>
			<div class="blurb">
								<div class="ico-star ico-header community" data-not-on-prod-class-change=""></div>
				<h2>Mission Able</h2>
				<p><?=$desc?></p>
				<div class="btn-cage">
										<a href="<?=$link?>" class="btn btn-lg btn-community" data-not-on-prod-class-change="">Learn More</a>
				</div>
			</div>
		</div>
	</section>
</article>
		</div>
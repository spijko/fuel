<section class="row">
<p><?=$content?></p>
</section>
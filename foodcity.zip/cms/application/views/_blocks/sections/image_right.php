<section class="row">
    <div class="col_1-3"><img src="<?=img_path($image)?>" /></div>
    <div class="col_2-3">
        <h3><?=$title?></h3>
        <p><?=$content?></p>
    </div>
</section>

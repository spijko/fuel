<div class="row padded">
			<article class="panel panel-default shadow-both">
	<section class="panel-body">
		<div class="col-xs-12">
			<h1 style="margin-top:15px">Our Mission</h1>
			<p><?=$desc?></p>
		</div>
	</section>
</article>
		</div>
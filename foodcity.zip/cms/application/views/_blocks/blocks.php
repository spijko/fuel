<?php
$my_data = array();
$my_data[] = array('name' => 'Darth Vader', 'weapon' => 'light saber');
//$my_data[] = array('name' => 'Han Solo', 'weapon' => 'blaster');
 
print_r( $this->fuel->layouts->options_list());
//print_r( $this->fuel->layouts->get());


 
?>
